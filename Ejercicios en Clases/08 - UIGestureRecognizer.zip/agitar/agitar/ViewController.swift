//
//  ViewController.swift
//  agitar
//
//  Created by Jordi Tormo Llàcer on 13/03/2020.
//  Copyright © 2020 UPV. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let deslizarR = UISwipeGestureRecognizer(target: self, action: #selector(handlerGesto(gesto:)))
        deslizarR.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(deslizarR)
        
        let deslizarL = UISwipeGestureRecognizer(target: self, action: #selector(handlerGesto(gesto:)))
        deslizarL.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(deslizarL)
    }

    
    @objc func handlerGesto(gesto:UIGestureRecognizer)
    {
        if let gestoDeslizar = gesto as? UISwipeGestureRecognizer
        {
            switch gestoDeslizar.direction
            {
                case UISwipeGestureRecognizer.Direction.right:
                    print("Deslizamiento hacia la derecha")
                
                case UISwipeGestureRecognizer.Direction.left:
                    print("Deslizamiento hacia la izquierda")
                
                default:
                    print("Gesto no esperado.")
            }
        }
        
        
    }
    
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?)
    {
        if event?.subtype == UIEvent.EventSubtype.motionShake
        {
            print("El dispositivo fue agitado")
        }
    }
    

}

