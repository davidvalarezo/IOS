//
//  ViewController.swift
//  temporizador
//
//  Created by Jordi Tormo Llàcer on 22/11/2019.
//  Copyright © 2019 Jordi Tormo Llàcer. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    var timer = Timer()
    var tiempoInicial = 900
    var tiempo = 0
    
    @IBOutlet weak var lblTimer: UILabel!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tiempo = tiempoInicial
        actualizarUI()
    }
    
    
    
    @objc func decrementarContador()
    {
        if tiempo > 0
        {
            tiempo -= 1
            actualizarUI()
        }
        else
        {
            timer.invalidate()
        }
        
    }
    
    
    

    
    @IBAction func actionPlay(_ sender: UIBarButtonItem)
    {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.decrementarContador), userInfo: nil, repeats: true)
    }
    
    @IBAction func actionPause(_ sender: UIBarButtonItem)
    {
        timer.invalidate()
    }
    
    
    @IBAction func actionMenos10(_ sender: UIBarButtonItem)
    {
        if tiempo > 10
        {
            tiempo -= 10
            actualizarUI()
        }
    }
    
    
    @IBAction func actionMas10(_ sender: UIBarButtonItem)
    {
        tiempo += 10
        actualizarUI()
    }
    
    
    @IBAction func actionReset(_ sender: UIBarButtonItem)
    {
        tiempo = tiempoInicial
        actualizarUI()
    }
    

    func actualizarUI()
    {
        lblTimer.text = String(tiempo)
    }
    
    
}

